class Customer {
	static int curr = 1;
	final int num;
	String name;
	Address ad;
	public Customer(String nam, Address adres) {
		this.num = curr++;
		this.name = nam;
		this.ad = adres;
	}
	public int getCustomerNumber() {
		return num;
	}
	public String getName() {
		return name;
	}
	public void setName(String s) {
		this.name = s;
	}
	public Address getAddress() {
		return ad;
	}
	public void setAddress(Address adres) {
		this.ad = adres;
	}
}