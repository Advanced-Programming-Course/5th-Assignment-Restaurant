public class Customer{
    private Address address_class;
    private static int num = 1;
    private int CustomerNumber;
    private String name_of_customer;
    
    public int getCustomerNumber(){
        return CustomerNumber;
    }
    public String getName(){
        return name_of_customer;
    }
    public void setName(String name_of_customer){
        this.name_of_customer = name_of_customer;
    }
    public Address getAddress(){
        return address_class;
    }
    public void setAddress(Address address_class){
        this.address_class = address_class;
    }
    //////////////////////
    public Customer(String name_of_customer,Address address_class){
        this.name_of_customer = name_of_customer;
        this.address_class = address_class;
        this.CustomerNumber = num;
        num++;
    }

}
