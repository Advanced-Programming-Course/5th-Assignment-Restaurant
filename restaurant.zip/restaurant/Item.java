class Item {
	Food food;
	int count;
	String description;
	public Item(Food fd, int cnt) {
		this.food = fd;
		this.count = cnt;
		this.description = "-";
	}
	public Item(Food fd, int cnt, String desc) {
		this.food = fd;
		this.count = cnt;
		this.description = desc;
	}
	public Food getFood() {
		return food;
	}
	public int getCount() {
		return count;
	}
	public String getDescription() {
		return description;
	}
}