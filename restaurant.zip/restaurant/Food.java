import java.util.Vector;

class Food {
	static Vector<Food> menu = new Vector<> ();
	int price;
	String food;
	public Food(String fd, int pr) {
		this.food = fd;
		this.price = pr;
		menu.add(this);
	}
	public String getName() {
		return food;
	}
	public int getPrice() {
		return price;
	}
	public static Vector<Food> getMenu() {
		return menu;
	}
}