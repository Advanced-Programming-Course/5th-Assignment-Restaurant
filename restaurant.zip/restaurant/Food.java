import java.util.Vector;
public class Food{
    private static Vector<Food> menu = new Vector<>();
    private int price;
    private String food;
    
    public String getName(){
        return food;
    }
    public int getPrice(){
        return price;
    }
    public static Vector<Food> getMenu(){
        return menu;
    }
    ////////////////////////////////////////////
    public Food(String food, int price){
        this.food = food;
        this.price = price;
        menu.add(this);
    }
}
