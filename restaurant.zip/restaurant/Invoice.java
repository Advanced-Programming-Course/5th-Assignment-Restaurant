Package InvoicePackage;

public class Invoice {
    private final Customer customer;
    private final Vector<Item> items = new Vector<>();
    private int state = -1;
    private static final float tax_rate = 0.094f;

    public Invoice(Customer customer) {
        this.customer = customer;
    }

    public boolean addItem(Item item) {
        if (state == -1) {
            items.add(item);
            return true;
        }
        return false;
    }

    public boolean removeItem(Item item) {
        if (state == -1 && items.contains(item)) {
            items.remove(item);
            return true;
        }
        return false;
    }

    public void nextStage() {
        state++;
    }

    public int getState() {
        return state;
    }

    public Vector<Item> getItems() {
        return items;
    }

    public int getTotalPrice() {
        int total = 0;
        for (Item item : items) {
            total += item.getFood().getPrice() * item.getCount();
        }
        total = (int) Math.ceil(total * (1 + tax_rate));
        return total;
    }
}
