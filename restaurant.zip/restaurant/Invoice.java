import java.util.Vector;
class Invoice{
    private Customer customer;
    private int state = -1;
    private Vector<Item> factor;
    private static final float tax_rate = 9.4f;

    public int getState() {
        return state;
    }
    public Customer getCustomer(){
        return customer;
    }
    public Invoice(Customer customer){
        this.customer = customer;
        this.state = -1;
        this.factor =new Vector<>();
    }
    public boolean addItem(Item item){
        if(this.state != -1){
            return false;
        }
        else{
            this.factor.add(item);
            return true;
        }
    }
    public boolean removeItem(Item item){
        if (state != -1){
            return false;
        }
        if(factor.contains(item)){
            factor.remove(item);
            return true;
        }
        return false;
    }
    public void nextStage(){
        state++;
    }
    public int getTotalPrice(){
        int price =0;
        for (Item item : factor) {
            price+=item.getFood().getPrice() * item.getCount();
        }

        double fprice = price*(100+tax_rate)/100;

        return (int) Math.ceil(fprice);
    }
    //////////////////////////////////////
    
    // in the test code
    public Vector<Item> getItems() {
        return factor;
    }

}
