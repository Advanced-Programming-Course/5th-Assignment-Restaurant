public class Address{
    public double latitude;
    public double longitude;
    public String written_address;
    
    public Address(double latitude, double longitude, String written_address){
        this.latitude = latitude;
        this.longitude = longitude;
        this.written_address = written_address;
    }
    // dar tuzihat omade esm distance_from bashe vali dar code distanceFrom hast!!
    public double distanceFrom(Address address){
        double x1 = this.latitude;
        double y1 = this.longitude;
        double x2 = address.latitude;
        double y2 = address.longitude;
        double x = x2 - x1;
        double y = y2 - y1;
        double d = Math.sqrt(x*x+y*y);
        return d;
    }
}
