Package AddressPackage;

public class Address {
    private Double latitude;
    private Double longitude;
    private String written_address;

    public Address(int latitude, int longitude, String written_address) {
        this.latitude = (double) latitude;
        this.longitude = (double) longitude;
        this.written_address = written_address;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public String getWrittenAddress() {
        return written_address;
    }

    public Double distanceFrom(Address otherAddress) {
        double latDiff = this.latitude - otherAddress.getLatitude();
        double lonDiff = this.longitude - otherAddress.getLongitude();
        return Math.sqrt(latDiff * latDiff + lonDiff * lonDiff);
    }
}
