class Address {
	double x, y;
	String written_address;
	public Address(double a, double b, String s) {
		this.x = a;
		this.y = b;
		this.written_address = s;
	}
	public double distance_from(Address other) {
		return Math.sqrt((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y));
	}
}